# Weekly Progress Log

## Week 1 (01/01/2026 – 07/01/2026)
- Project setup, main.cpp file created
- Initialize Git repository
- Planned game features

## Week 2
- Implemented player movement
- Added basic input controls

## Week 3
- Added enemies and AI behavior
- Collision detection implemented

## Week 4
- Level design and scoring system
- UI elements added

## Week 5
- Debugging and final testing
- Prepare assets

## Week 6
- Final demo completed
- Documentation and deliverables finalized