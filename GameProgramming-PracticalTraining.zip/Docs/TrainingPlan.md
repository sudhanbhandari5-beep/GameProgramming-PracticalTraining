# Practical Training Plan – C++ Game Development

**Student Name:** Sudhan Bhandari  
**Student ID:** 2506759  
**Degree Program:** BBA, Game Programming  
**Credits:** 30 ECTS  

**Training Provider / Project:** GitHub-based C++ Game Development project  
**Repository Link:** [Insert your GitHub repo link here]  

**Supervisor / Contact Person:** Leena / KAMK Practical Training Coordinator  

### Training Objectives
- Apply C++ programming skills in game development
- Develop project independently with documentation
- Produce final deliverables: game demo, code, report

### Duration & Hours
- Start Date: 01/01/2026  
- End Date: 31/03/2026 (fast-track 3 months)  
- Weekly Hours: 30–40  

### Deliverables
- GitHub repository with code, assets, and documentation
- Weekly progress logs in /Docs/Progress.md
- Final demo and report in /Deliverables