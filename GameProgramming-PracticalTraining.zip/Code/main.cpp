// main.cpp - Start your C++ project here
#include <iostream>

int main() {
    std::cout << "Hello, Game Programming Practical Training!" << std::endl;
    return 0;
}